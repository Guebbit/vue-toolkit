TODO
 - Copypaste the README.md from boilerplate-node-backend-mongodb